const product = {
    name: "New Balance 530",
    price: "120,00€",
    description: "The MR530 combines contemporary style with performance, featuring an ABZORB midsole and a mesh-synthetic upper for a tech-inspired, distinctive look.",
    imageUrl: "https://stickystore.tn/wp-content/uploads/2023/02/Untitled-design-8.png"
  };
  
  export default product;
  