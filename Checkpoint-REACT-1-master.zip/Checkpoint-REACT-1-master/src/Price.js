import React from 'react';

function ProductPrice() {
  return <p>120,00€</p>;
}

export default ProductPrice;
