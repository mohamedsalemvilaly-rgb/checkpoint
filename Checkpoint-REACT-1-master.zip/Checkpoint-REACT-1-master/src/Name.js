import React from 'react';

function ProductName() {
  return <h5>New Balance 530</h5>;
}

export default ProductName;
