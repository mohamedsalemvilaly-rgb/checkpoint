import React from 'react';

function ProductDescription() {
  return <p>The MR530 combines contemporary style with performance, featuring an ABZORB midsole 
    and a mesh-synthetic upper for a tech-inspired, distinctive look.</p>;
}

export default ProductDescription;
