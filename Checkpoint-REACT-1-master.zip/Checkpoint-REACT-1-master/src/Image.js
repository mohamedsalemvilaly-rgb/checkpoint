import React from 'react';

function ProductImage() {
  return <img src="https://stickystore.tn/wp-content/uploads/2023/02/Untitled-design-8.png" alt="Product"/>;
}

export default ProductImage;
