import React, { Component } from 'react'
import './App.css'


export default class AppClass extends Component {
    constructor(props){
        super(props)
        this.state={
            fullName:"Fatma Dahech",
            bio:"A graphic designer with a Master’s in UX/UI design, awarded with highest honors. Currently, I’m expanding my skills through a software development bootcamp, combining creativity and technical expertise to craft innovative digital solutions.",
            imgSrc:"/Profile Picture.jpg",
            profession:"Software Developer",
            show:false,
            elapsedTime:0
        }
    }
    show=()=>{{this.setState({show:!this.state.show})}}
    componentDidMount=()=>{this.interval=setInterval(()=>{this.setState({ elapsedTime:this.state.elapsedTime+1})},1000);}
    componentWillUnmount=()=>{clearInterval(this.interval)}

  render() {
    return (
        <div>
        {this.state.show && (
            <div className="profile-card">
                <img src={this.state.imgSrc} alt={this.state.fullName} />
                    <h1>{this.state.fullName}</h1>
                    <h2>{this.state.profession}</h2>
                    <p>{this.state.bio}</p>
                    <p style={{fontWeight:'bold', fontSize:'14px'}}>Time since mounted: {this.state.elapsedTime} seconds</p>
            </div>
        )}
                <button onClick={this.show}>Show Profile</button>
        </div>
    )
  }
}



//plus=()=>{
    //{this.setState({count:this.state.count+1})}}
//minus=()=>{
    //{this.setState({count:this.state.count-1})}}
    //<button onClick={this.plus}>+</button>
    //<button onClick={this.minus}>-</button>
    //<span>{this.state.count}</span>