const players = [
    {
      name: "Mohamed Aboutrika",
      team: "Retired (Al Ahly)",
      nationality: "Egyptian",
      jerseyNumber: 22,
      age: 45,
      imageUrl: "/images/mohamed_aboutrika.jpg",
    },
    {
      name: "Freddie Kanoute",
      team: "Retired (Sevilla, Mali)",
      nationality: "Malian",
      jerseyNumber: 12,
      age: 46,
      imageUrl: "/images/freddie_kanoute.jpg",
    },
    {
      name: "Mesut Özil",
      team: "Retired (Arsenal)",
      nationality: "German",
      jerseyNumber: 10,
      age: 35,
      imageUrl: "/images/mesut_ozil.jpg",
  },
    {
      name: "Mahmoud Wadi",
      team: "Pyramids FC",
      nationality: "Palestinian",
      jerseyNumber: 9,
      age: 29,
      imageUrl: "/images/mahmoud_wadi.jpg",
    },
  ];
  
  export default players;
  