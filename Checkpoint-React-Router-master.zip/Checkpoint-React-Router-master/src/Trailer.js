import React from 'react'
import { useParams } from 'react-router-dom';
import { Link } from 'react-router-dom';
import "./Trailer.css"


const Trailer = ({movies}) => {
    const {id} = useParams();
    const foundMovie = movies.find((el) => el.id === +id);
  return (
    <div>
     <h1>{foundMovie.title}</h1>
     <p>{foundMovie.description}</p>
     <iframe 
     className="trailerVid"
     width="560" 
     height="315" 
     src={foundMovie.Trailer}
     title="YouTube video player" 
     frameborder="0" 
     allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
     referrerpolicy="strict-origin-when-cross-origin" 
     allowfullscreen>
     </iframe>
     <br>
     </br>
     <Link to="/" >
      <button type="submit" className="submit-button">
              Back To Movies
      </button>
        </Link>
    </div>
  )
}

export default Trailer
