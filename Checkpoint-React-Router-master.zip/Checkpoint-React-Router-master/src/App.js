import { useState } from 'react';
import './App.css';
import MovieList from './MovieList';
import Search from './Search';
import AddMovie from './AddMovie';
import { Routes, Route } from 'react-router-dom';
import Trailer from './Trailer';

function App() {
  const [movies, setMovies]= useState([
    { id: 1,
      title: 'Bleach',
      description:"Bleach is a Japanese anime series based on Tite Kubo's manga. Bleach follows Ichigo Kurosaki, a teenager who becomes a Soul Reaper to protect humans from evil spirits called Hollows. With the help of his allies, he battles powerful foes and uncovers dark secrets about his world.", 
      posterURL:"https://static.bandainamcoent.eu/high/bleach/bleach-rebirth-of-souls/00-page-setup/BRS-header-mobile.jpg",
      rating: 5,
      Trailer: "https://www.youtube.com/watch?v=_aFFywK7pYI"
  },
    { id: 2,
      title: 'Demon Slayer',
      description:"Demon Slayer is a Japanese anime series based on Koyoharu Gotouge's manga. It follows Tanjiro Kamado, whose family is killed by demons, and his sister, Nezuko, is turned into one. To save her and seek revenge, Tanjiro joins the Demon Slayer Corps, battling powerful demons.", 
      posterURL:"https://static.toiimg.com/thumb/resizemode-4,width-1280,height-720,msid-108824901/108824901.jpg",
      rating: 5,
      Trailer: "https://www.youtube.com/watch?v=wyiZWYMilgk"
  },
    { id: 3,
      title: 'Jujutsu Kaisen',
      description:" Jujutsu Kaisen is a Japanese anime series based on Gege Akutami's manga. It follows Yuji Itadori, a student who gains supernatural powers after swallowing a cursed object, and joins a school to fight cursed spirits. The series is known for its intense battles and complex characters.", 
      posterURL:"https://p325k7wa.twic.pics/high/jujutsu-kaisen/jujutsu-kaisen-cursed-clash/00-page-setup/JJK-header-mobile2.jpg?twic=v1/resize=760/step=10/quality=80",
      rating: 3,
      Trailer: "https://www.youtube.com/watch?v=eUTtCcHVVOA"
  },
    { id: 4,
     title: 'Naruto',
     description:" Jujutsu Kaisen is a Japanese anime series based on Gege Akutami's manga. It follows Yuji Itadori, a student who gains supernatural powers after swallowing a cursed object, and joins a school to fight cursed spirits. The series is known for its intense battles and complex characters.",
     posterURL:"https://i.pinimg.com/736x/0a/80/68/0a80682781856dec5129cab851c10de8.jpg",
     rating: 4,
     Trailer: "https://www.youtube.com/watch?v=eUTtCcHVVOA"
},
    { id: 5,
    title: 'Black Clover',
    description:" Black Clover is a Japanese anime series based on Yūki Tabata's manga. It follows Asta, a boy born without magic in a world where magic is everything, as he strives to become the Wizard King and battles powerful enemies alongside his friends. Throughout his journey, Asta learns alot.",
    posterURL:"https://m.media-amazon.com/images/S/pv-target-images/5336a1f60b1bb848d9a5e478e95430de30e2ca62f276d3e7c781dfc4f6d484e8._SX1080_FMjpg_.jpg",
    rating: 5,
    Trailer: "https://www.youtube.com/watch?v=PrgxJ1_sUcs"
},
    
  ])
  const [search, setSearch] = useState({ title: '', rating: 0 });
  const [showAddMovie, setShowAddMovie] = useState(false);

  const filteredMovies = movies.filter(movie =>
    movie.title.toLowerCase().includes(search.title.toLowerCase()) &&
    (search.rating === 0 || movie.rating >= search.rating)
  );

  return (
    <div className="App">
      <h1 style={{ color: "#C76C35", fontSize: "30px" , textAlign: "center" , fontWeight:"bold" }}> Anime Movie App</h1>
      <Search
        onTitleChange={(title) => setSearch(prev => ({ ...prev, title }))}
        onRatingChange={(rating) => setSearch(prev => ({ ...prev, rating }))}
        searchRating={search.rating}
      />
      <button className="add-movie-btn" onClick={() => setShowAddMovie(true)}>
        Add New Movie
      </button>
      <Routes>
        <Route path="/" element={<>
{showAddMovie && (
        <AddMovie 
          onAdd={(newMovie) => {
            setMovies([...movies, newMovie]);
            setShowAddMovie(false);
          }}
          onClose={() => setShowAddMovie(false)}
        />
      )}
      <MovieList movies={filteredMovies} />
        </>} />
        <Route path="/Trailer/:id" element={<Trailer movies={movies}/>} />
      </Routes>
      
    </div>
  );
}

export default App;