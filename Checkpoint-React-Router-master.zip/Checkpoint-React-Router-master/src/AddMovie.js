import React, { useState } from 'react';
import './AddMovie.css';

const AddMovie = ({ onAdd, onClose }) => {
  const [newMovie, setNewMovie] = useState({
    title: '',
    description: '',
    posterURL: '',
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (newMovie.title && newMovie.description && newMovie.posterURL) {
      onAdd(newMovie);
    }
  };

  return (
    <div className="modal">
      <div className="modal-content">
        <div className="modal-header">
          <h2>Add New Movie</h2>
          <button onClick={onClose} className="close-button">X</button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="form-field">
            <input
              type="text"
              placeholder="Movie title"
              value={newMovie.title}
              onChange={(e) => setNewMovie({ ...newMovie, title: e.target.value })}
              required
            />
          </div>

          <div className="form-field">
            <textarea
              placeholder="Movie description"
              value={newMovie.description}
              onChange={(e) => setNewMovie({ ...newMovie, description: e.target.value })}
              required
            />
          </div>

          <div className="form-field">
            <input
              type="url"
              placeholder="Poster URL"
              value={newMovie.posterURL}
              onChange={(e) => setNewMovie({ ...newMovie, posterURL: e.target.value })}
              required
            />
          </div>

          <div className="form-actions">
            <button type="button" onClick={onClose} className="cancel-button">
              Cancel
            </button>
            <button type="submit" className="submit-button">
              Add Movie
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddMovie;
