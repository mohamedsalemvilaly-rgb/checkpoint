import React from 'react'
import "./MovieCard.css"
import "@fortawesome/fontawesome-free/css/all.min.css";
import "./Rate.css";

const MovieCard = ({movie}) => {
  
  return (
    <div>
<div id="movie-card-list">
<div className="movie-card"style={{ backgroundImage: `url(${movie.posterURL})` }}>
  <div class="movie-card" data-movie="Blade Runner">
    <div class="movie-card__overlay"></div>
    <div class="movie-card__content">
      <div class="movie-card__header">
        <h1 class="movie-card__title">{movie.title}</h1>
        <div className="movie-card__rating">
        <i class="fas fa-star"></i>
          <span class="movie-card__rating-value">{movie.rating}</span>
</div>
</div>
      <p class="movie-card__desc">{movie.description}</p>
    </div>
    
  </div>
</div>
    </div>
    
    </div>
  )
}

export default MovieCard
