import React from 'react';
import './Search.css';

const Search = ({ onTitleChange, onRatingChange, searchRating }) => {
  return (
    <div className="search__container">
      <input
        className="search__input"
        type="text"
        placeholder="Search by title"
        onChange={(e) => onTitleChange(e.target.value)}
      />
      <div className="rating-filter">
        <span>Filter by rating : </span>
        {[1, 2, 3, 4, 5].map((rating) => (
          <i
            key={rating}
            className={`fas fa-star ${rating <= searchRating ? 'active' : ''}`}
            onClick={() => onRatingChange(rating === searchRating ? 0 : rating)}
          />
        ))}
      </div>
    </div>
  );
};

export default Search;
